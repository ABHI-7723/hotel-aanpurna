var popup=document.getElementById('popup');
    function CloseSlide(){
        popup.classList.remove("open-slide")
    }
